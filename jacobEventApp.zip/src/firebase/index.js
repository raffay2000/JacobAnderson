import {FirebaseConfig} from './config';

const firebase = new FirebaseConfig();

export default firebase;