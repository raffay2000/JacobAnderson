export const primary = "#0078FF";
export const white = "#ffffff";
export const black = "#000000";
export const lightGray = "#5E5E5E";
export const gray = "#DCDCDC";
export const darkGray = "#B4B4B4";
export const purple = "#4640FF";
export const yellow = "#ffe234";
export const red = "#E41F2C";



