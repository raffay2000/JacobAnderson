

import Bold from './Lato-Bold.ttf';
import Light from './Lato-Light.ttf';
import Black from './Lato-Black.ttf';
import Regular from './Lato-Regular.ttf';
import Thin from './Lato-Thin.ttf';

export {
    Bold,
    Light,
    Black,
    Regular,
    Thin
}