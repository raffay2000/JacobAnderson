export const API = "https://webdesignpreviews.com/custom/jacobanderson_app/api/";
// export const API = "http://192.168.18.163/jacobanderson_app/public/api/";