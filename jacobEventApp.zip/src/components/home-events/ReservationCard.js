import React from 'react';
import {
    View,
    Text,
    StyleSheet
} from 'react-native';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { primary, red, white } from '../../assets/colors';
import { useTheme } from '../../theme/ThemeContext';
import { Button } from '../common/Button';

const ReservationCard = ({Onpress, TotalSeats, RemainingSeats, date, month, Price}) => {
    const {colors} = useTheme();

    return(
        <View style={styles.container}>
            <View style={styles.row}>
                <View style={styles.card}>
                    <Text style={styles.text}>{TotalSeats}</Text>
                    <Text style={styles.subText}>Total Seats</Text>
                </View>
                <View style={styles.card}>
                    <Text style={styles.text}>{RemainingSeats}</Text>
                    <Text style={styles.subText}>Reserved Seats</Text>
                </View>
                <View style={styles.card}>
                    <Text style={styles.text}>{date}</Text>
                    <Text style={styles.subText}>{month}</Text>
                </View>
            </View>
            <View style={[styles.row,{marginTop:hp('3%')}]}>
                <Text style={[styles.price,{color:colors.text}]}>${Price} Per Seat</Text>
                <Button
                    onPress={Onpress}
                    color={red}
                    text="Reserve Now"
                    textColor={white}
                    style={{flex:1, marginTop:0}}
                />
            </View>
        </View>
    )
}
export default ReservationCard;

const styles = StyleSheet.create({
    container:{
        marginTop:hp('5%'),
        marginBottom:hp('5%'),
    },
    row:{
        flexDirection:'row',
        justifyContent:'space-around',
        alignItems:'center'
    },
    card:{
        height:hp('10%'),
        width:hp('15%'),
        padding:hp('2%'),
        borderRadius:hp('1%'),
        backgroundColor:primary,
        justifyContent:'space-between',
        alignItems:'center',
    },
    text:{
        color:white,
        fontSize:hp('3%'),
        fontFamily:"Bold",
    },
    subText:{
        color:white,
        // marginTop:'1%',
        fontSize:hp('2%'),
        fontFamily:"Regular",
        textAlign:"center",
        // height:hp('4%')
    },
    price:{
        flex:1,
        textAlign:'center',
        fontFamily:"Bold",
        fontSize:hp('3%'),
    }
})